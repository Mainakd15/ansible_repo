Changelog
=========

[1.7.2] - 2026-05-12
--------------------

### Bug Fixes

- fix: Use verbosity level 3 for no_log (#172)

[1.7.1] - 2026-05-07
--------------------

### Bug Fixes

- fix: issues found via code review (#170)

### Other Changes

- ci: testing farm tests now use 5 managed nodes [citest_skip] (#167)
- test: comment out NFS mounts from /etc/fstab for bootable test failures (#168)
- ci: bump actions/github-script from 8 to 9 (#169)

[1.7.0] - 2026-04-28
--------------------

### New Features

- feat: add list command to report the status of LVM snapshots for specified VGs/LVs (#164)
- feat: add role fingerprints to syslog (#165)

### Other Changes

- ci: tox-lsr version 3.15.0 [citest_skip] (#150)
- ci: Add Fedora 43, remove Fedora 41 from Testing Farm CI (#151)
- ci: bump actions/upload-artifact from 6 to 7 (#153)
- ci: tox-lsr 3.17.0 - container test improvements, use ansible 2.20 for fedora 43 [citest_skip] (#155)
- ci: tox-lsr 3.17.1 - previous update broke container tests, this fixes them [citest_skip] (#156)
- ci: fix yum repos to use devel site instead of old site name [citest_skip] (#158)
- ci: use codecov @v6 [citest_skip] (#159)
- ci: update header for run_role_with_clear_facts [citest_skip] (#160)
- test: support ansible-test milestone version 2.22 [citest_skip] (#161)
- ci: Comply with Ansible partner certification checking [citest_skip] (#162)
- ci: ansible-lint requires dependencies to be installed [citest_skip] (#163)

[1.6.4] - 2026-02-06
--------------------

### Bug Fixes

- fix: problem with bootable flag not getting passed properly to snapm (#138)
- fix: check create_snapshot_set function for boot parameter (#148)

### Other Changes

- ci: bump ansible/ansible-lint from 25 to 26 (#145)
- ci: skip most CI checks if title contains citest skip [citest_skip] (#146)
- ci: ansible-lint - remove .collection directory from converted collection [citest_skip] (#147)

[1.6.3] - 2026-01-13
--------------------

### Other Changes

- refactor: handle INJECT_FACTS_AS_VARS=false by using ansible_facts instead (#141)
- ci: use ANSIBLE_INJECT_FACT_VARS=false by default for testing (#142)

[1.6.2] - 2026-01-06
--------------------

### Other Changes

- ci: bump gha checkout from v5 to v6 (#134)
- ci: bump actions/checkout from 5 to 6 (#135)
- ci: add qemu tests for Fedora 43, drop Fedora 41 (#136)
- ci: bump actions/upload-artifact from 5 to 6 (#137)
- docs: fix copyright in license (#139)

[1.6.1] - 2025-11-17
--------------------

### Bug Fixes

- fix: cannot use community-general version 12 - no py27 and py36 support (#132)

[1.6.0] - 2025-11-13
--------------------

### New Features

- feat: add support for "bootable" snapshots (#115)

### Other Changes

- ci: rollout several recent changes to CI testing (#117)
- ci: support openSUSE Leap in qemu/kvm test matrix (#118)
- ci: use the new epel feature to enable EPEL for testing farm (#119)
- ci: use tox-lsr 3.12.0 for osbuild_config.yml feature (#121)
- ci: use JSON format for __bootc_validation (#122)
- ci: bump actions/checkout from 4 to 5 (#123)
- ci: bump actions/github-script from 7 to 8 (#124)
- ci: bump actions/setup-python from 5 to 6 (#125)
- ci: bump actions/upload-artifact from 4 to 5 (#126)
- ci: bump github/codeql-action from 3 to 4 (#127)
- ci: use versioned upload-artifact instead of master; bump codeql-action to v4; bump upload-artifact to v5 (#128)
- ci: bump tox-lsr to 3.13.0 (#129)
- ci: bump tox-lsr to 3.14.0 - this moves standard-inventory-qcow2 to tox-lsr (#130)

[1.5.2] - 2025-06-16
--------------------

### Bug Fixes

- fix: correct issues with LC_ALL and LVM_COMMAND_PROFILE and snapshot manager (#112)

### Other Changes

- ci: Add support for bootc end-to-end validation tests (#110)
- ci: Use ansible 2.19 for fedora 42 testing; support python 3.13 (#111)

[1.5.1] - 2025-05-19
--------------------

### Other Changes

- refactor: add Ansible test python boilerplate (#107)

[1.5.0] - 2025-05-19
--------------------

### New Features

- feat: add support for snapshot manager backing the role (#97)

### Other Changes

- ci: ansible-plugin-scan is disabled for now (#87)
- ci: bump ansible-lint to v25; provide collection requirements for ansible-lint (#90)
- ci: Check spelling with codespell (#91)
- ci: Add test plan that runs CI tests and customize it for each role (#92)
- ci: In test plans, prefix all relate variables with SR_ (#93)
- ci: Fix bug with ARTIFACTS_URL after prefixing with SR_ (#94)
- ci: several changes related to new qemu test, ansible-lint, python versions, ubuntu versions (#95)
- ci: use tox-lsr 3.6.0; improve qemu test logging (#98)
- ci: skip storage scsi, nvme tests in github qemu ci (#99)
- ci: Bump sclorg/testing-farm-as-github-action from 3 to 4 (#100)
- ci: bump tox-lsr to 3.8.0; rename qemu/kvm tests (#101)
- ci: Add Fedora 42; use tox-lsr 3.9.0; use lsr-report-errors for qemu tests (#105)

[1.4.3] - 2025-01-09
--------------------

### Other Changes

- ci: Bump codecov/codecov-action from 4 to 5 (#83)
- ci: Use Fedora 41, drop Fedora 39 (#84)
- ci: Use Fedora 41, drop Fedora 39 - part two (#85)

[1.4.2] - 2024-10-30
--------------------

### Other Changes

- ci: Add tags to TF workflow, allow more [citest bad] formats (#77)
- ci: ansible-test action now requires ansible-core version (#78)
- ci: add YAML header to github action workflow files (#79)
- refactor: Use vars/RedHat_N.yml symlink for CentOS, Rocky, Alma wherever possible (#81)

[1.4.1] - 2024-08-16
--------------------

### Other Changes

- ci: Add tft plan and workflow (#68)
- ci: Update fmf plan to add a separate job to prepare managed nodes (#70)
- ci: Bump sclorg/testing-farm-as-github-action from 2 to 3 (#71)
- ci: Add workflow for ci_test bad, use remote fmf plan (#72)
- ci: Fix missing slash in ARTIFACTS_URL (#73)
- test: should only operate on test_ vgs (#75)

[1.4.0] - 2024-07-15
--------------------

### New Features

- feat: rewrite snapshot.py as an Ansible module / add support for thin origins (#58)

### Bug Fixes

- fix: add support for EL10 (#66)

### Other Changes

- ci: use tox-lsr 3.3.0 which uses ansible-test 2.17 (#60)
- ci: tox-lsr 3.4.0 - fix py27 tests; move other checks to py310 (#62)
- ci: Add supported_ansible_also to .ansible-lint (#63)
- ci: ansible-lint action now requires absolute directory (#64)

[1.3.3] - 2024-05-21
--------------------

### Other Changes

- refactor: translate command line arguments into JSON format and use common functions  (#55)

[1.3.2] - 2024-04-04
--------------------

### Other Changes

- test: use storage_udevadm_trigger, gather debug when fail (#49)
- ci: Bump ansible/ansible-lint from 6 to 24 (#50)
- ci: Bump mathieudutour/github-tag-action from 6.1 to 6.2 (#53)

[1.3.1] - 2024-02-21
--------------------

### Bug Fixes

- fix: better error handling for all platforms and ansible versions (#47)

[1.3.0] - 2024-02-20
--------------------

### New Features

- feat: add support for snapshot_lvm_vg_include (#39)

### Bug Fixes

- fix: ostree test failures - use /var/mnt (#37)
- fix: ensure role is idempotent and supports check mode (#41)

### Other Changes

- refactor: use iterator function for listing vgs, lvs (#36)
- refactor: centralize test setup/cleanup - add cleanup debugging (#38)

[1.2.0] - 2024-02-13
--------------------

### New Features

- feat: add support to extending existing snapshots to required percentage (#22)
- feat: add support for the "list" command (#31)
- feat: add support mounting/unmounting snapshots and origins (#34)

### Bug Fixes

- fix: rename the clean command to remove (#24)

### Other Changes

- ci: Bump codecov/codecov-action from 3 to 4 (#25)
- ci: fix python unit test - copy pytest config to tests/unit (#26)
- refactor: fix linter issues (#27)
- docs: remove template badge (#28)

[1.1.0] - 2024-01-26
--------------------

### New Features

- feat: add support for reverting LV back to state of snapshot  (#15)

[1.0.0] - 2024-01-24
--------------------

### New Features

- feat: New Role - snapshot - support for LVM snapshots

## Security and Disclosure Information Policy for the Podman Ansible Collections Project

The Podman Ansible Collections Project follows the [Security and Disclosure Information Policy](https://github.com/containers/common/blob/main/SECURITY.md) for the Containers Projects.

